angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('servSan', {
    url: '/page1',
    templateUrl: 'templates/servSan.html',
    controller: 'servSanCtrl'
  })

  .state('cadastro', {
    url: '/page5',
    templateUrl: 'templates/cadastro.html',
    controller: 'cadastroCtrl'
  })

  .state('servHome', {
    url: '/page6',
    templateUrl: 'templates/servHome.html',
    controller: 'servHomeCtrl'
  })

  .state('oferecerServiOs', {
    url: '/page7',
    templateUrl: 'templates/oferecerServiOs.html',
    controller: 'oferecerServiOsCtrl'
  })

  .state('buscarServiO', {
    url: '/page10',
    templateUrl: 'templates/buscarServiO.html',
    controller: 'buscarServiOCtrl'
  })

  .state('todosOsServiOs', {
    url: '/page11',
    templateUrl: 'templates/todosOsServiOs.html',
    controller: 'todosOsServiOsCtrl'
  })

  .state('criarDemanda', {
    url: '/page12',
    templateUrl: 'templates/criarDemanda.html',
    controller: 'criarDemandaCtrl'
  })

  .state('notificaEs', {
    url: '/page8',
    templateUrl: 'templates/notificaEs.html',
    controller: 'notificaEsCtrl'
  })

  .state('contratos', {
    url: '/page9',
    templateUrl: 'templates/contratos.html',
    controller: 'contratosCtrl'
  })

  .state('editarDados', {
    url: '/page13',
    templateUrl: 'templates/editarDados.html',
    controller: 'editarDadosCtrl'
  })

  .state('alterarSenha', {
    url: '/page15',
    templateUrl: 'templates/alterarSenha.html',
    controller: 'alterarSenhaCtrl'
  })

  .state('dados', {
    url: '/page16',
    templateUrl: 'templates/dados.html',
    controller: 'dadosCtrl'
  })

$urlRouterProvider.otherwise('/page5')


});